from setuptools import setup, find_packages

setup(
    name='rev',
    version='0.1',
    packages=find_packages(),
    url='',
    license='MIT',
    author='hhro',
    author_email='hhro9712@gmail.com',
    description='Useful utils for reverser',
    classifiers=[
                'Programming Language :: Python :: 2.7'
    ],  
    zip_safe=False
)
